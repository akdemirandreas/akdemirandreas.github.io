# Andreas Akdemir Personal Website

Compliance and regulatory-risk focused GitHub Pages portfolio.

## Deploy
Upload `index.html` to the root of the `akdemirandreas.github.io` repository, replacing the current file.

The CSS, JavaScript, and profile image are embedded in `index.html`, so no separate assets are required.
